import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { Settings as SettingsIcon, User, Bell, Shield, CircleHelp as HelpCircle } from 'lucide-react-native';

export default function SettingsScreen() {
  const settingsOptions = [
    {
      icon: <User size={24} color="#6B7280" />,
      title: 'Profile Settings',
      subtitle: 'Manage your personal information',
    },
    {
      icon: <Bell size={24} color="#6B7280" />,
      title: 'Notifications',
      subtitle: 'Control your notification preferences',
    },
    {
      icon: <Shield size={24} color="#6B7280" />,
      title: 'Privacy & Security',
      subtitle: 'Manage your privacy settings',
    },
    {
      icon: <HelpCircle size={24} color="#6B7280" />,
      title: 'Help & Support',
      subtitle: 'Get help and contact support',
    },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <SettingsIcon size={32} color="#3B82F6" />
        <Text style={styles.headerTitle}>Settings</Text>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>Account</Text>
        {settingsOptions.map((option, index) => (
          <TouchableOpacity key={index} style={styles.settingItem}>
            <View style={styles.settingIcon}>
              {option.icon}
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>{option.title}</Text>
              <Text style={styles.settingSubtitle}>{option.subtitle}</Text>
            </View>
          </TouchableOpacity>
        ))}

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>About This Demo</Text>
          <Text style={styles.infoText}>
            This is a demonstration of a mobile app signup flow with best practices including:
            {'\n\n'}• Multi-step progression with clear navigation
            {'\n'}• Real-time validation and error handling
            {'\n'}• Personalization through interest selection
            {'\n'}• Secure password creation with strength indicators
            {'\n'}• Smooth animations and transitions
            {'\n'}• Mobile-optimized design and interactions
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937',
    marginLeft: 12,
  },
  content: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 16,
  },
  settingItem: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    color: '#6B7280',
  },
  infoCard: {
    backgroundColor: '#EBF8FF',
    borderRadius: 12,
    padding: 20,
    marginTop: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#3B82F6',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#1F2937',
    lineHeight: 20,
  },
});