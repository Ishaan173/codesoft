import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  Pressable,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  interpolate,
  runOnJS,
  useAnimatedGestureHandler,
} from 'react-native-reanimated';
import { PanGestureHandler } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChevronLeft, ChevronRight, Check, Eye, EyeOff, Smartphone, Mail, Lock, Heart } from 'lucide-react-native';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
  interests: string[];
  notifications: boolean;
}

interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
}

const INTERESTS = [
  { name: 'Technology', emoji: '💻' },
  { name: 'Travel', emoji: '✈️' },
  { name: 'Photography', emoji: '📸' },
  { name: 'Cooking', emoji: '👨‍🍳' },
  { name: 'Sports', emoji: '⚽' },
  { name: 'Music', emoji: '🎵' },
  { name: 'Art', emoji: '🎨' },
  { name: 'Reading', emoji: '📚' },
  { name: 'Gaming', emoji: '🎮' },
  { name: 'Fitness', emoji: '💪' },
];

export default function SignupFlow() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    interests: [],
    notifications: true,
  });
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  const translateX = useSharedValue(0);
  const buttonScale = useSharedValue(1);
  const progressScale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  const buttonAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: buttonScale.value }],
  }));

  const progressAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: progressScale.value }],
  }));

  const validateStep = (step: number): boolean => {
    const newErrors: ValidationErrors = {};

    switch (step) {
      case 0:
        if (!formData.firstName.trim()) {
          newErrors.firstName = 'First name is required';
        } else if (formData.firstName.trim().length < 2) {
          newErrors.firstName = 'First name must be at least 2 characters';
        }
        if (!formData.lastName.trim()) {
          newErrors.lastName = 'Last name is required';
        } else if (formData.lastName.trim().length < 2) {
          newErrors.lastName = 'Last name must be at least 2 characters';
        }
        break;
      case 1:
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!formData.email.trim()) {
          newErrors.email = 'Email is required';
        } else if (!emailRegex.test(formData.email)) {
          newErrors.email = 'Please enter a valid email address';
        }
        break;
      case 2:
        if (!formData.password) {
          newErrors.password = 'Password is required';
        } else if (formData.password.length < 8) {
          newErrors.password = 'Password must be at least 8 characters';
        }
        if (!formData.confirmPassword) {
          newErrors.confirmPassword = 'Please confirm your password';
        } else if (formData.password !== formData.confirmPassword) {
          newErrors.confirmPassword = 'Passwords do not match';
        }
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const animateButton = () => {
    buttonScale.value = withSpring(0.95, { duration: 100 }, () => {
      buttonScale.value = withSpring(1, { duration: 100 });
    });
  };

  const animateProgress = () => {
    progressScale.value = withSpring(1.05, { duration: 200 }, () => {
      progressScale.value = withSpring(1, { duration: 200 });
    });
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      animateButton();
      animateProgress();
      
      const newStep = currentStep + 1;
      translateX.value = withSpring(-newStep * screenWidth, {
        damping: 20,
        stiffness: 90,
      });
      setCurrentStep(newStep);
    }
  };

  const prevStep = () => {
    const newStep = currentStep - 1;
    translateX.value = withSpring(-newStep * screenWidth, {
      damping: 20,
      stiffness: 90,
    });
    setCurrentStep(newStep);
  };

  const toggleInterest = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleSignup = () => {
    animateButton();
    console.log('Signup completed:', formData);
    nextStep();
  };

  const getPasswordStrength = () => {
    const password = formData.password;
    let strength = 0;
    
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    return strength;
  };

  const getPasswordStrengthText = () => {
    const strength = getPasswordStrength();
    if (strength < 2) return 'Weak';
    if (strength < 4) return 'Medium';
    return 'Strong';
  };

  const getPasswordStrengthColor = () => {
    const strength = getPasswordStrength();
    if (strength < 2) return '#EF4444';
    if (strength < 4) return '#F59E0B';
    return '#10B981';
  };

  const renderStep = (step: number) => {
    switch (step) {
      case 0:
        return (
          <View style={styles.stepContainer}>
            <View style={styles.iconContainer}>
              <Smartphone size={40} color="#3B82F6" />
            </View>
            <Text style={styles.stepTitle}>Welcome! Let's get started</Text>
            <Text style={styles.stepSubtitle}>Tell us your name to personalize your experience</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.label}>First Name</Text>
              <TextInput
                style={[styles.input, errors.firstName && styles.inputError]}
                value={formData.firstName}
                onChangeText={(text) => {
                  setFormData(prev => ({ ...prev, firstName: text }));
                  if (errors.firstName) setErrors(prev => ({ ...prev, firstName: undefined }));
                }}
                placeholder="Enter your first name"
                autoCapitalize="words"
                autoCorrect={false}
                returnKeyType="next"
                placeholderTextColor="#9CA3AF"
              />
              {errors.firstName && <Text style={styles.errorText}>{errors.firstName}</Text>}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Last Name</Text>
              <TextInput
                style={[styles.input, errors.lastName && styles.inputError]}
                value={formData.lastName}
                onChangeText={(text) => {
                  setFormData(prev => ({ ...prev, lastName: text }));
                  if (errors.lastName) setErrors(prev => ({ ...prev, lastName: undefined }));
                }}
                placeholder="Enter your last name"
                autoCapitalize="words"
                autoCorrect={false}
                returnKeyType="next"
                placeholderTextColor="#9CA3AF"
              />
              {errors.lastName && <Text style={styles.errorText}>{errors.lastName}</Text>}
            </View>
          </View>
        );

      case 1:
        return (
          <View style={styles.stepContainer}>
            <View style={styles.iconContainer}>
              <Mail size={40} color="#3B82F6" />
            </View>
            <Text style={styles.stepTitle}>Hi {formData.firstName}!</Text>
            <Text style={styles.stepSubtitle}>What's your email address?</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email Address</Text>
              <TextInput
                style={[styles.input, errors.email && styles.inputError]}
                value={formData.email}
                onChangeText={(text) => {
                  setFormData(prev => ({ ...prev, email: text }));
                  if (errors.email) setErrors(prev => ({ ...prev, email: undefined }));
                }}
                placeholder="Enter your email"
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="email"
                returnKeyType="next"
                placeholderTextColor="#9CA3AF"
              />
              {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}
            </View>

            <View style={styles.tipCard}>
              <Text style={styles.tipText}>💡 We'll use this email to send you important updates about your account</Text>
            </View>
          </View>
        );

      case 2:
        return (
          <View style={styles.stepContainer}>
            <View style={styles.iconContainer}>
              <Lock size={40} color="#3B82F6" />
            </View>
            <Text style={styles.stepTitle}>Create a secure password</Text>
            <Text style={styles.stepSubtitle}>Your password should be at least 8 characters long</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Password</Text>
              <View style={styles.passwordContainer}>
                <TextInput
                  style={[styles.passwordInput, errors.password && styles.inputError]}
                  value={formData.password}
                  onChangeText={(text) => {
                    setFormData(prev => ({ ...prev, password: text }));
                    if (errors.password) setErrors(prev => ({ ...prev, password: undefined }));
                  }}
                  placeholder="Create a password"
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                  autoCorrect={false}
                  returnKeyType="next"
                  placeholderTextColor="#9CA3AF"
                />
                <TouchableOpacity
                  style={styles.eyeButton}
                  onPress={() => setShowPassword(!showPassword)}
                  activeOpacity={0.7}
                >
                  {showPassword ? <EyeOff size={20} color="#6B7280" /> : <Eye size={20} color="#6B7280" />}
                </TouchableOpacity>
              </View>
              {formData.password.length > 0 && (
                <View style={styles.passwordStrength}>
                  <View style={styles.strengthBarContainer}>
                    <View style={[styles.strengthBar, { backgroundColor: getPasswordStrengthColor(), width: `${(getPasswordStrength() / 5) * 100}%` }]} />
                  </View>
                  <Text style={[styles.strengthText, { color: getPasswordStrengthColor() }]}>
                    {getPasswordStrengthText()}
                  </Text>
                </View>
              )}
              {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Confirm Password</Text>
              <View style={styles.passwordContainer}>
                <TextInput
                  style={[styles.passwordInput, errors.confirmPassword && styles.inputError]}
                  value={formData.confirmPassword}
                  onChangeText={(text) => {
                    setFormData(prev => ({ ...prev, confirmPassword: text }));
                    if (errors.confirmPassword) setErrors(prev => ({ ...prev, confirmPassword: undefined }));
                  }}
                  placeholder="Confirm your password"
                  secureTextEntry={!showConfirmPassword}
                  autoCapitalize="none"
                  autoCorrect={false}
                  returnKeyType="done"
                  placeholderTextColor="#9CA3AF"
                />
                <TouchableOpacity
                  style={styles.eyeButton}
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                  activeOpacity={0.7}
                >
                  {showConfirmPassword ? <EyeOff size={20} color="#6B7280" /> : <Eye size={20} color="#6B7280" />}
                </TouchableOpacity>
              </View>
              {errors.confirmPassword && <Text style={styles.errorText}>{errors.confirmPassword}</Text>}
            </View>
          </View>
        );

      case 3:
        return (
          <View style={styles.stepContainer}>
            <View style={styles.iconContainer}>
              <Heart size={40} color="#3B82F6" />
            </View>
            <Text style={styles.stepTitle}>What interests you?</Text>
            <Text style={styles.stepSubtitle}>Select topics to personalize your experience (optional)</Text>
            
            <View style={styles.interestsGrid}>
              {INTERESTS.map((interest) => (
                <Pressable
                  key={interest.name}
                  style={({ pressed }) => [
                    styles.interestChip,
                    formData.interests.includes(interest.name) && styles.interestChipSelected,
                    pressed && styles.interestChipPressed,
                  ]}
                  onPress={() => toggleInterest(interest.name)}
                  android_ripple={{ color: 'rgba(59, 130, 246, 0.1)' }}
                >
                  <Text style={styles.interestEmoji}>{interest.emoji}</Text>
                  <Text style={[
                    styles.interestText,
                    formData.interests.includes(interest.name) && styles.interestTextSelected
                  ]}>
                    {interest.name}
                  </Text>
                </Pressable>
              ))}
            </View>

            <View style={styles.notificationToggle}>
              <TouchableOpacity
                style={[styles.toggle, formData.notifications && styles.toggleActive]}
                onPress={() => setFormData(prev => ({ ...prev, notifications: !prev.notifications }))}
                activeOpacity={0.8}
              >
                <Animated.View style={[
                  styles.toggleThumb,
                  { transform: [{ translateX: formData.notifications ? 24 : 2 }] }
                ]} />
              </TouchableOpacity>
              <View style={styles.toggleLabel}>
                <Text style={styles.toggleTitle}>Push Notifications</Text>
                <Text style={styles.toggleSubtitle}>Get updates about new features and content</Text>
              </View>
            </View>
          </View>
        );

      case 4:
        return (
          <View style={styles.stepContainer}>
            <Animated.View 
              style={[styles.successIcon, {
                transform: [{ scale: withSpring(1, { damping: 8, stiffness: 100 }) }]
              }]}
            >
              <Check size={48} color="#10B981" />
            </Animated.View>
            <Text style={styles.successTitle}>Welcome aboard!</Text>
            <Text style={styles.successSubtitle}>
              Your account has been created successfully. You're all set to start exploring!
            </Text>
            
            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>Account Summary</Text>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Name:</Text>
                <Text style={styles.summaryValue}>{formData.firstName} {formData.lastName}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Email:</Text>
                <Text style={styles.summaryValue}>{formData.email}</Text>
              </View>
              {formData.interests.length > 0 && (
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Interests:</Text>
                  <Text style={styles.summaryValue}>{formData.interests.slice(0, 3).join(', ')}{formData.interests.length > 3 ? '...' : ''}</Text>
                </View>
              )}
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Notifications:</Text>
                <Text style={styles.summaryValue}>{formData.notifications ? 'Enabled' : 'Disabled'}</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.getStartedButton} activeOpacity={0.8}>
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.getStartedGradient}
              >
                <Text style={styles.getStartedText}>Get Started</Text>
                <ChevronRight size={20} color="#ffffff" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );

      default:
        return null;
    }
  };

  const gestureHandler = useAnimatedGestureHandler({
    onStart: (_, context) => {
      context.startX = translateX.value;
    },
    onActive: (event, context) => {
      if (currentStep > 0 && event.translationX > 0) {
        translateX.value = context.startX + event.translationX * 0.5;
      }
    },
    onEnd: (event) => {
      if (event.translationX > 100 && currentStep > 0) {
        runOnJS(prevStep)();
      } else {
        translateX.value = withSpring(-currentStep * screenWidth);
      }
    },
  });

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1D4ED8" />
      
      <LinearGradient
        colors={['#3B82F6', '#1D4ED8', '#1E40AF']}
        style={styles.gradient}
      >
        {/* Header */}
        <View style={styles.header}>
          {currentStep > 0 && currentStep < 4 && (
            <TouchableOpacity 
              style={styles.backButton} 
              onPress={prevStep}
              activeOpacity={0.7}
            >
              <BlurView intensity={20} style={styles.backButtonBlur}>
                <ChevronLeft size={24} color="#ffffff" />
              </BlurView>
            </TouchableOpacity>
          )}
          
          {currentStep < 4 && (
            <Animated.View style={[styles.progressContainer, progressAnimatedStyle]}>
              <Text style={styles.progressText}>Step {currentStep + 1} of 4</Text>
              <View style={styles.progressBar}>
                <Animated.View 
                  style={[
                    styles.progressFill, 
                    { 
                      width: withTiming(`${((currentStep + 1) / 4) * 100}%`, { duration: 500 })
                    }
                  ]} 
                />
              </View>
            </Animated.View>
          )}
        </View>

        {/* Content */}
        <KeyboardAvoidingView 
          style={styles.content}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          <PanGestureHandler onGestureEvent={gestureHandler}>
            <Animated.View style={styles.scrollContainer}>
              <ScrollView 
                style={styles.scrollView}
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
              >
                <Animated.View style={[styles.stepsContainer, animatedStyle]}>
                  {[0, 1, 2, 3, 4].map((step) => (
                    <View key={step} style={styles.step}>
                      {renderStep(step)}
                    </View>
                  ))}
                </Animated.View>
              </ScrollView>
            </Animated.View>
          </PanGestureHandler>
        </KeyboardAvoidingView>

        {/* Footer */}
        {currentStep < 4 && (
          <View style={styles.footer}>
            {currentStep === 3 ? (
              <View style={styles.buttonGroup}>
                <Animated.View style={buttonAnimatedStyle}>
                  <TouchableOpacity 
                    style={styles.primaryButton} 
                    onPress={handleSignup}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['#ffffff', '#f8fafc']}
                      style={styles.buttonGradient}
                    >
                      <Text style={styles.primaryButtonText}>Create Account</Text>
                      <Check size={20} color="#3B82F6" />
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
                
                <TouchableOpacity 
                  style={styles.skipButton} 
                  onPress={handleSignup}
                  activeOpacity={0.7}
                >
                  <Text style={styles.skipButtonText}>Skip for now</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <Animated.View style={buttonAnimatedStyle}>
                <TouchableOpacity 
                  style={styles.primaryButton} 
                  onPress={nextStep}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={['#ffffff', '#f8fafc']}
                    style={styles.buttonGradient}
                  >
                    <Text style={styles.primaryButtonText}>Continue</Text>
                    <ChevronRight size={20} color="#3B82F6" />
                  </LinearGradient>
                </TouchableOpacity>
              </Animated.View>
            )}
          </View>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1D4ED8',
  },
  gradient: {
    flex: 1,
  },
  header: {
    paddingTop: Platform.OS === 'ios' ? 60 : StatusBar.currentHeight ? StatusBar.currentHeight + 20 : 40,
    paddingHorizontal: 20,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 100,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 16,
    overflow: 'hidden',
  },
  backButtonBlur: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressContainer: {
    flex: 1,
  },
  progressText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
    textAlign: 'center',
  },
  progressBar: {
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#ffffff',
    borderRadius: 3,
  },
  content: {
    flex: 1,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    minHeight: screenHeight * 0.7,
  },
  stepsContainer: {
    flexDirection: 'row',
    width: screenWidth * 5,
    minHeight: '100%',
  },
  step: {
    width: screenWidth,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  stepContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 32,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
    minHeight: screenHeight * 0.5,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#EBF8FF',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: 24,
  },
  stepTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 12,
    textAlign: 'center',
  },
  stepSubtitle: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 40,
    textAlign: 'center',
    lineHeight: 24,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  input: {
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderRadius: 16,
    padding: 18,
    fontSize: 16,
    backgroundColor: '#F9FAFB',
    color: '#1F2937',
  },
  inputError: {
    borderColor: '#EF4444',
    backgroundColor: '#FEF2F2',
  },
  passwordContainer: {
    position: 'relative',
  },
  passwordInput: {
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderRadius: 16,
    padding: 18,
    paddingRight: 60,
    fontSize: 16,
    backgroundColor: '#F9FAFB',
    color: '#1F2937',
  },
  eyeButton: {
    position: 'absolute',
    right: 18,
    top: 18,
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  passwordStrength: {
    marginTop: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  strengthBarContainer: {
    flex: 1,
    height: 6,
    backgroundColor: '#E5E7EB',
    borderRadius: 3,
    marginRight: 12,
    overflow: 'hidden',
  },
  strengthBar: {
    height: '100%',
    borderRadius: 3,
  },
  strengthText: {
    fontSize: 14,
    fontWeight: '600',
    minWidth: 60,
  },
  errorText: {
    color: '#EF4444',
    fontSize: 14,
    marginTop: 8,
    fontWeight: '500',
  },
  tipCard: {
    backgroundColor: '#EBF8FF',
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#3B82F6',
  },
  tipText: {
    fontSize: 14,
    color: '#1E40AF',
    lineHeight: 20,
  },
  interestsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 32,
  },
  interestChip: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    backgroundColor: '#F9FAFB',
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: (screenWidth - 80) / 2 - 6,
    justifyContent: 'center',
  },
  interestChipSelected: {
    borderColor: '#3B82F6',
    backgroundColor: '#3B82F6',
  },
  interestChipPressed: {
    transform: [{ scale: 0.95 }],
  },
  interestEmoji: {
    fontSize: 16,
    marginRight: 8,
  },
  interestText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
  },
  interestTextSelected: {
    color: '#ffffff',
  },
  notificationToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
  },
  toggle: {
    width: 52,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E5E7EB',
    marginRight: 16,
    justifyContent: 'center',
  },
  toggleActive: {
    backgroundColor: '#3B82F6',
  },
  toggleThumb: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  toggleLabel: {
    flex: 1,
  },
  toggleTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 4,
  },
  toggleSubtitle: {
    fontSize: 14,
    color: '#6B7280',
  },
  successIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#ECFDF5',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: 32,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  successTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 16,
  },
  successSubtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  summaryCard: {
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
    marginBottom: 32,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
    width: 80,
  },
  summaryValue: {
    fontSize: 14,
    color: '#1F2937',
    fontWeight: '600',
    flex: 1,
  },
  getStartedButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  getStartedGradient: {
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  getStartedText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
    marginRight: 8,
  },
  footer: {
    padding: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 20,
  },
  buttonGroup: {
    gap: 16,
  },
  primaryButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  buttonGradient: {
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryButtonText: {
    color: '#3B82F6',
    fontSize: 18,
    fontWeight: '600',
    marginRight: 8,
  },
  skipButton: {
    alignItems: 'center',
    padding: 12,
  },
  skipButtonText: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 16,
    fontWeight: '500',
  },
});