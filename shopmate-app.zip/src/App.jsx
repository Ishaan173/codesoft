
import React, { useState } from "react";

const categories = ["Electronics", "Fashion", "Home Decor", "Books", "Toys"];

const allProducts = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: "$99",
    image: "https://source.unsplash.com/300x200/?headphones",
  },
  {
    id: 2,
    name: "Smart Watch",
    price: "$149",
    image: "https://source.unsplash.com/300x200/?smartwatch",
  },
  {
    id: 3,
    name: "Bluetooth Speaker",
    price: "$79",
    image: "https://source.unsplash.com/300x200/?speaker",
  },
  {
    id: 4,
    name: "Decorative Vase",
    price: "$39",
    image: "https://source.unsplash.com/300x200/?vase",
  },
  {
    id: 5,
    name: "Kids Toy Car",
    price: "$25",
    image: "https://source.unsplash.com/300x200/?toycar",
  },
  {
    id: 6,
    name: "Bestseller Novel",
    price: "$18",
    image: "https://source.unsplash.com/300x200/?book",
  },
];

export default function App() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredProducts = allProducts.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{ fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif", backgroundColor: "#f2f4f7", minHeight: "100vh" }}>
      <nav style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '1rem 2rem',
        backgroundColor: '#ffffff',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 'bold', color: '#007bff' }}>🛒 ShopMate</h1>
        <ul style={{ display: 'flex', gap: '1.5rem', listStyle: 'none', margin: 0 }}>
          <li style={{ cursor: 'pointer' }}>Home</li>
          <li style={{ cursor: 'pointer' }}>Categories</li>
          <li style={{ cursor: 'pointer' }}>Cart</li>
          <li style={{ cursor: 'pointer' }}>Profile</li>
        </ul>
      </nav>
      <div style={{ maxWidth: '800px', margin: '2rem auto', padding: '0 1rem' }}>
        <input
          type="text"
          placeholder="Search for products..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            width: "100%",
            padding: "0.8rem",
            borderRadius: "8px",
            border: "1px solid #ccc",
            fontSize: "1rem",
            boxShadow: "0 2px 5px rgba(0,0,0,0.05)"
          }}
        />
      </div>
      <section style={{ maxWidth: '1000px', margin: '2rem auto', padding: '0 1rem' }}>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Categories</h2>
        <ul style={{ display: "flex", flexWrap: "wrap", gap: "1rem", padding: 0, listStyle: "none" }}>
          {categories.map((cat, index) => (
            <li
              key={index}
              style={{
                background: "#ffffff",
                border: "1px solid #ddd",
                padding: "0.75rem 1.5rem",
                borderRadius: "10px",
                boxShadow: "0 1px 4px rgba(0,0,0,0.05)",
                cursor: "pointer",
                transition: "transform 0.2s ease",
              }}
              onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
            >
              {cat}
            </li>
          ))}
        </ul>
      </section>
      <section style={{ maxWidth: '1000px', margin: '2rem auto', padding: '0 1rem' }}>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Featured Products</h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "2rem" }}>
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <div
                key={product.id}
                style={{
                  background: "#ffffff",
                  borderRadius: "12px",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                  overflow: "hidden",
                  width: "250px",
                  transition: "transform 0.2s ease"
                }}
                onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.03)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
              >
                <img src={product.image} alt={product.name} style={{ width: "100%", height: "160px", objectFit: "cover" }} />
                <div style={{ padding: "1rem" }}>
                  <h3 style={{ fontSize: "1.2rem", marginBottom: "0.5rem" }}>{product.name}</h3>
                  <p style={{ color: "#007bff", fontWeight: "bold" }}>{product.price}</p>
                  <button
                    style={{
                      marginTop: "0.75rem",
                      padding: "0.6rem 1rem",
                      borderRadius: "6px",
                      background: "#007bff",
                      color: "white",
                      border: "none",
                      cursor: "pointer",
                      fontWeight: "bold",
                      transition: "background 0.2s ease"
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = '#0056b3'}
                    onMouseLeave={e => e.currentTarget.style.background = '#007bff'}
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p style={{ fontSize: "1.1rem", color: "#666" }}>No products match your search.</p>
          )}
        </div>
      </section>
      <footer style={{ textAlign: "center", padding: "2rem 0", color: "#666" }}>
        © 2025 ShopMate. All rights reserved.
      </footer>
    </div>
  );
}
