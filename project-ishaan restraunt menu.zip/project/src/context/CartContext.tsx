import React, { createContext, useContext, useReducer, useEffect, useRef, useCallback } from 'react';
import { toast } from 'react-hot-toast';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
  cholesterolLevel: number;
  restaurantId?: string;
  estimatedDeliveryTime?: string;
}

interface CartState {
  items: CartItem[];
  total: number;
  totalCholesterol: number;
  maxCholesterolLevel: number;
  lastWarningTime: number | null;
  deliveryFee: number;
  taxes: number;
  packagingFee: number;
}

type CartAction =
  | { type: 'ADD_ITEM'; payload: Omit<CartItem, 'quantity'> }
  | { type: 'REMOVE_ITEM'; payload: number }
  | { type: 'UPDATE_QUANTITY'; payload: { id: number; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'SET_MAX_CHOLESTEROL'; payload: number };

const CartContext = createContext<{
  state: CartState;
  dispatch: React.Dispatch<CartAction>;
} | null>(null);

const MAX_ALLOWED_CHOLESTEROL = 300;
const CHOLESTEROL_WARNING_COOLDOWN = 1000 * 60 * 30; // 30 minutes
const FREE_DELIVERY_THRESHOLD = 50;
const TAX_RATE = 0.1; // 10%
const PACKAGING_FEE_PER_ITEM = 0.50;

const calculateDeliveryFee = (total: number): number => {
  return total >= FREE_DELIVERY_THRESHOLD ? 0 : 4.99;
};

const calculateTaxes = (subtotal: number): number => {
  return subtotal * TAX_RATE;
};

const calculatePackagingFee = (itemCount: number): number => {
  return itemCount * PACKAGING_FEE_PER_ITEM;
};

const initialState: CartState = {
  items: [],
  total: 0,
  totalCholesterol: 0,
  maxCholesterolLevel: 200,
  lastWarningTime: null,
  deliveryFee: 0,
  taxes: 0,
  packagingFee: 0
};

// Save cart state to localStorage
const saveCartState = (state: CartState) => {
  try {
    localStorage.setItem('cart', JSON.stringify(state));
  } catch (error) {
    console.error('Error saving cart state:', error);
  }
};

// Load cart state from localStorage
const loadCartState = (): CartState => {
  try {
    const savedState = localStorage.getItem('cart');
    return savedState ? JSON.parse(savedState) : initialState;
  } catch (error) {
    console.error('Error loading cart state:', error);
    return initialState;
  }
};

const cartReducer = (state: CartState, action: CartAction): CartState => {
  switch (action.type) {
    case 'ADD_ITEM': {
      const existingItem = state.items.find(item => item.id === action.payload.id);
      const newCholesterolLevel = state.totalCholesterol + action.payload.cholesterolLevel;
      const now = Date.now();

      let updatedItems;
      let newSubtotal;

      if (existingItem) {
        updatedItems = state.items.map(item =>
          item.id === action.payload.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
        newSubtotal = state.total + action.payload.price;
      } else {
        updatedItems = [...state.items, { ...action.payload, quantity: 1 }];
        newSubtotal = state.total + action.payload.price;
      }

      const newDeliveryFee = calculateDeliveryFee(newSubtotal);
      const newTaxes = calculateTaxes(newSubtotal);
      const newPackagingFee = calculatePackagingFee(updatedItems.reduce((sum, item) => sum + item.quantity, 0));

      const newState = {
        ...state,
        items: updatedItems,
        total: newSubtotal + newDeliveryFee + newTaxes + newPackagingFee,
        totalCholesterol: newCholesterolLevel,
        lastWarningTime: now,
        deliveryFee: newDeliveryFee,
        taxes: newTaxes,
        packagingFee: newPackagingFee
      };

      saveCartState(newState);
      return newState;
    }

    case 'REMOVE_ITEM': {
      const item = state.items.find(item => item.id === action.payload);
      if (!item) return state;

      const updatedItems = state.items.filter(item => item.id !== action.payload);
      const newSubtotal = state.total - (item.price * item.quantity);
      const newDeliveryFee = calculateDeliveryFee(newSubtotal);
      const newTaxes = calculateTaxes(newSubtotal);
      const newPackagingFee = calculatePackagingFee(updatedItems.reduce((sum, item) => sum + item.quantity, 0));

      const newState = {
        ...state,
        items: updatedItems,
        total: newSubtotal + newDeliveryFee + newTaxes + newPackagingFee,
        totalCholesterol: state.totalCholesterol - (item.cholesterolLevel * item.quantity),
        deliveryFee: newDeliveryFee,
        taxes: newTaxes,
        packagingFee: newPackagingFee
      };

      saveCartState(newState);
      return newState;
    }

    case 'UPDATE_QUANTITY': {
      const item = state.items.find(item => item.id === action.payload.id);
      if (!item) return state;

      const quantityDiff = action.payload.quantity - item.quantity;
      const newCholesterolLevel = state.totalCholesterol + (item.cholesterolLevel * quantityDiff);

      const updatedItems = state.items.map(item =>
        item.id === action.payload.id
          ? { ...item, quantity: action.payload.quantity }
          : item
      );

      const newSubtotal = state.total + (item.price * quantityDiff);
      const newDeliveryFee = calculateDeliveryFee(newSubtotal);
      const newTaxes = calculateTaxes(newSubtotal);
      const newPackagingFee = calculatePackagingFee(updatedItems.reduce((sum, item) => sum + item.quantity, 0));

      const newState = {
        ...state,
        items: updatedItems,
        total: newSubtotal + newDeliveryFee + newTaxes + newPackagingFee,
        totalCholesterol: newCholesterolLevel,
        deliveryFee: newDeliveryFee,
        taxes: newTaxes,
        packagingFee: newPackagingFee
      };

      saveCartState(newState);
      return newState;
    }

    case 'SET_MAX_CHOLESTEROL': {
      if (action.payload > MAX_ALLOWED_CHOLESTEROL) {
        return state;
      }
      const newState = {
        ...state,
        maxCholesterolLevel: action.payload
      };
      saveCartState(newState);
      return newState;
    }

    case 'CLEAR_CART': {
      saveCartState(initialState);
      return initialState;
    }

    default:
      return state;
  }
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, loadCartState());
  const lastAction = useRef<CartAction | null>(null);

  const handleCholesterolWarning = useCallback((newLevel: number, currentLevel: number) => {
    toast((t) => (
      <div>
        <p className="font-bold text-red-600">High Cholesterol Warning!</p>
        <p className="text-sm">Adding this item will exceed your cholesterol limit of {state.maxCholesterolLevel} mg/dL.</p>
        <p className="text-sm">Current: {currentLevel} mg/dL</p>
        <p className="text-sm">After adding: {newLevel} mg/dL</p>
        <div className="mt-2 flex justify-end gap-2">
          <button
            className="px-3 py-1 text-sm bg-gray-200 rounded-full"
            onClick={() => toast.dismiss(t.id)}
          >
            Cancel
          </button>
          <button
            className="px-3 py-1 text-sm bg-orange-600 text-white rounded-full"
            onClick={() => {
              toast.dismiss(t.id);
              toast.success('Item added to cart');
            }}
          >
            Add Anyway
          </button>
        </div>
      </div>
    ), { duration: 6000 });
  }, [state.maxCholesterolLevel]);

  useEffect(() => {
    if (!lastAction.current) return;

    switch (lastAction.current.type) {
      case 'ADD_ITEM': {
        const newCholesterolLevel = state.totalCholesterol;
        const now = Date.now();
        const shouldWarn = newCholesterolLevel > state.maxCholesterolLevel && 
                          (!state.lastWarningTime || (now - state.lastWarningTime) > CHOLESTEROL_WARNING_COOLDOWN);

        if (shouldWarn) {
          handleCholesterolWarning(
            newCholesterolLevel,
            state.totalCholesterol - lastAction.current.payload.cholesterolLevel
          );
        } else {
          toast.success('Item added to cart');
        }
        break;
      }
      case 'REMOVE_ITEM':
        toast.success('Item removed from cart');
        break;
      case 'UPDATE_QUANTITY': {
        const item = state.items.find(item => item.id === lastAction.current.payload.id);
        if (item && lastAction.current.payload.quantity > item.quantity) {
          toast.success('Quantity updated');
        }
        break;
      }
      case 'SET_MAX_CHOLESTEROL':
        if (lastAction.current.payload > MAX_ALLOWED_CHOLESTEROL) {
          toast.error(`Maximum allowed cholesterol level is ${MAX_ALLOWED_CHOLESTEROL} mg/dL`);
        }
        break;
      case 'CLEAR_CART':
        toast.success('Cart cleared');
        break;
    }

    lastAction.current = null;
  }, [state, handleCholesterolWarning]);

  const dispatchWithTracking = useCallback((action: CartAction) => {
    lastAction.current = action;
    dispatch(action);
  }, []);

  return (
    <CartContext.Provider value={{ state, dispatch: dispatchWithTracking }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};