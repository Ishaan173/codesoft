import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

const Menu = () => {
  const [activeCategory, setActiveCategory] = React.useState('indian');
  const { dispatch } = useCart();

  const categories = [
    { id: 'indian', name: 'Indian Cuisine' },
    { id: 'chinese', name: 'Chinese Cuisine' },
    { id: 'continental', name: 'Continental Cuisine' },
    { id: 'salads', name: 'Fresh Salads' }
  ];

  const dishes = {
    indian: [
      {
        id: 101,
        name: "Butter Chicken",
        description: "Tender chicken in rich tomato-butter sauce",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 85
      },
      {
        id: 102,
        name: "Dal Makhani",
        description: "Black lentils simmered overnight with cream",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1626500155537-99bb120e8c3c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 45
      },
      {
        id: 103,
        name: "Biryani",
        description: "Fragrant rice with spices and tender meat",
        price: 18.99,
        image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 104,
        name: "Palak Paneer",
        description: "Cottage cheese in creamy spinach gravy",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 55
      },
      {
        id: 105,
        name: "Rogan Josh",
        description: "Kashmiri lamb curry with aromatic spices",
        price: 19.99,
        image: "https://images.unsplash.com/photo-1545247181-516773cae754?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 80
      },
      {
        id: 106,
        name: "Malai Kofta",
        description: "Potato and paneer dumplings in rich gravy",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 107,
        name: "Chicken Tikka Masala",
        description: "Grilled chicken in spiced tomato sauce",
        price: 17.99,
        image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 108,
        name: "Chole Bhature",
        description: "Spiced chickpeas with fried bread",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1626074353765-517a681e40be?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 60
      },
      {
        id: 109,
        name: "Fish Curry",
        description: "Coastal style fish in coconut curry",
        price: 20.99,
        image: "https://images.unsplash.com/photo-1626509653291-c51a8ee8c4a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 50
      },
      {
        id: 110,
        name: "Vegetable Korma",
        description: "Mixed vegetables in mild curry sauce",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 40
      },
      {
        id: 111,
        name: "Tandoori Chicken",
        description: "Clay oven roasted marinated chicken",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 112,
        name: "Kadai Paneer",
        description: "Cottage cheese in spicy bell pepper gravy",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1631452180775-8b4e4b9c0ba8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 113,
        name: "Mutton Vindaloo",
        description: "Spicy Goan style lamb curry",
        price: 21.99,
        image: "https://images.unsplash.com/photo-1545247181-516773cae754?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 85
      },
      {
        id: 114,
        name: "Paneer Butter Masala",
        description: "Cottage cheese in rich tomato gravy",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 115,
        name: "Chicken Biryani",
        description: "Aromatic rice with spiced chicken",
        price: 18.99,
        image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 116,
        name: "Dal Tadka",
        description: "Yellow lentils with tempered spices",
        price: 11.99,
        image: "https://images.unsplash.com/photo-1626500155537-99bb120e8c3c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 35
      },
      {
        id: 117,
        name: "Shahi Paneer",
        description: "Royal cottage cheese curry",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 80
      },
      {
        id: 118,
        name: "Chicken Korma",
        description: "Mild chicken curry with nuts",
        price: 17.99,
        image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 119,
        name: "Aloo Gobi",
        description: "Potato and cauliflower curry",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 30
      },
      {
        id: 120,
        name: "Lamb Keema",
        description: "Minced lamb with peas",
        price: 19.99,
        image: "https://images.unsplash.com/photo-1545247181-516773cae754?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      }
    ],
    chinese: [
      {
        id: 201,
        name: "Kung Pao Chicken",
        description: "Spicy diced chicken with peanuts",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1525755662778-989d0524087e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 202,
        name: "Mapo Tofu",
        description: "Spicy tofu with minced pork",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1582321282374-e09fa9564172?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 45
      },
      {
        id: 203,
        name: "Sweet and Sour Pork",
        description: "Crispy pork in tangy sauce",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1525755662778-989d0524087e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 204,
        name: "Dim Sum Platter",
        description: "Assorted steamed dumplings",
        price: 18.99,
        image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 55
      },
      {
        id: 205,
        name: "Peking Duck",
        description: "Roasted duck with pancakes",
        price: 29.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 85
      },
      {
        id: 206,
        name: "Chow Mein",
        description: "Stir-fried noodles with vegetables",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 40
      },
      {
        id: 207,
        name: "Hot Pot",
        description: "Simmering pot of broth with ingredients",
        price: 25.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 60
      },
      {
        id: 208,
        name: "General Tso's Chicken",
        description: "Sweet and spicy crispy chicken",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1525755662778-989d0524087e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 209,
        name: "Beef with Broccoli",
        description: "Stir-fried beef and broccoli",
        price: 17.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 210,
        name: "Egg Foo Young",
        description: "Chinese style omelet",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 80
      },
      {
        id: 211,
        name: "Szechuan Shrimp",
        description: "Spicy shrimp with vegetables",
        price: 18.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 55
      },
      {
        id: 212,
        name: "Lo Mein",
        description: "Soft noodles with mixed vegetables",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 45
      },
      {
        id: 213,
        name: "Orange Chicken",
        description: "Crispy chicken in citrus sauce",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1525755662778-989d0524087e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 214,
        name: "Mongolian Beef",
        description: "Stir-fried beef with scallions",
        price: 18.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 215,
        name: "Sesame Chicken",
        description: "Crispy chicken with sesame sauce",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1525755662778-989d0524087e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 216,
        name: "Shrimp Fried Rice",
        description: "Wok-fried rice with shrimp",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 50
      },
      {
        id: 217,
        name: "Salt and Pepper Squid",
        description: "Crispy squid with spicy seasoning",
        price: 17.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 60
      },
      {
        id: 218,
        name: "Chinese Eggplant",
        description: "Braised eggplant in garlic sauce",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 35
      },
      {
        id: 219,
        name: "Honey Walnut Prawns",
        description: "Crispy prawns in sweet sauce",
        price: 19.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 220,
        name: "Ma Po Eggplant",
        description: "Spicy eggplant with minced pork",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 45
      }
    ],
    continental: [
      {
        id: 301,
        name: "Beef Wellington",
        description: "Beef tenderloin wrapped in pastry",
        price: 34.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 90
      },
      {
        id: 302,
        name: "Coq au Vin",
        description: "Braised chicken in wine sauce",
        price: 26.99,
        image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 303,
        name: "Grilled Salmon",
        description: "Fresh salmon with herbs",
        price: 24.99,
        image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 60
      },
      {
        id: 304,
        name: "Mushroom Risotto",
        description: "Creamy rice with wild mushrooms",
        price: 19.99,
        image: "https://images.unsplash.com/photo-1476124369491-e7addf5db371?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 45
      },
      {
        id: 305,
        name: "Rack of Lamb",
        description: "Herb-crusted lamb rack",
        price: 36.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 85
      },
      {
        id: 306,
        name: "Lobster Thermidor",
        description: "Lobster in rich cream sauce",
        price: 42.99,
        image: "https://images.unsplash.com/photo-1533777857889-4be7c70b33f7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 80
      },
      {
        id: 307,
        name: "Duck Confit",
        description: "Slow-cooked duck leg",
        price: 28.99,
        image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 308,
        name: "Steak au Poivre",
        description: "Pepper-crusted steak",
        price: 32.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 80
      },
      {
        id: 309,
        name: "Seafood Paella",
        description: "Spanish rice with mixed seafood",
        price: 29.99,
        image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 310,
        name: "Veal Marsala",
        description: "Veal scaloppine with mushrooms",
        price: 27.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 311,
        name: "Beef Bourguignon",
        description: "Classic French beef stew",
        price: 25.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 312,
        name: "Chicken Cordon Bleu",
        description: "Stuffed chicken breast",
        price: 23.99,
        image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 80
      },
      {
        id: 313,
        name: "Osso Buco",
        description: "Braised veal shanks",
        price: 31.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 314,
        name: "Sole Meunière",
        description: "Pan-fried sole with butter sauce",
        price: 28.99,
        image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 65
      },
      {
        id: 315,
        name: "Ratatouille",
        description: "Provençal vegetable stew",
        price: 19.99,
        image: "https://images.unsplash.com/photo-1476124369491-e7addf5db371?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 30
      },
      {
        id: 316,
        name: "Moules Marinières",
        description: "Mussels in white wine sauce",
        price: 22.99,
        image: "https://images.unsplash.com/photo-1533777857889-4be7c70b33f7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 55
      },
      {
        id: 317,
        name: "Wiener Schnitzel",
        description: "Breaded veal cutlet",
        price: 26.99,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 75
      },
      {
        id: 318,
        name: "Bouillabaisse",
        description: "Provençal fish stew",
        price: 32.99,
        image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 60
      },
      {
        id: 319,
        name: "Cassoulet",
        description: "French bean and meat casserole",
        price: 24.99,
        image: "https://images.unsplash.com/photo-1476124369491-e7addf5db371?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 70
      },
      {
        id: 320,
        name: "Trout Amandine",
        description: "Pan-fried trout with almonds",
        price: 25.99,
        image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 55
      }
    ],
    salads: [
      {
        id: 401,
        name: "Mediterranean Salad",
        description: "Fresh vegetables with feta cheese",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=1171&q=80",
        cholesterolLevel: 15
      },
      {
        id: 402,
        name: "Caesar Salad",
        description: "Romaine lettuce with Caesar dressing",
        price: 11.99,
        image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 25
      },
      {
        id: 403,
        name: "Greek Salad",
        description: "Traditional Greek salad with olives",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?ixlib=rb-4.0.3&auto=format&fit=crop&w=1171&q=80",
        cholesterolLevel: 20
      },
      {
        id: 404,
        name: "Quinoa Bowl",
        description: "Quinoa with roasted vegetables",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 10
      },
      {
        id: 405,
        name: "Cobb Salad",
        description: "Classic American Cobb salad",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 35
      },
      {
        id: 406,
        name: "Asian Slaw",
        description: "Crunchy vegetables with sesame dressing",
        price: 11.99,
        image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 15
      },
      {
        id: 407,
        name: "Caprese Salad",
        description: "Tomatoes with fresh mozzarella",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1592417817098-8fd3d9eb14a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 25
      },
      {
        id: 408,
        name: "Waldorf Salad",
        description: "Apples, celery, and walnuts",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?ixlib=rb-4.0.3&auto=format&fit=crop& w=1170&q=80",
        cholesterolLevel: 20
      },
      {
        id: 409,
        name: "Nicoise Salad",
        description: "Tuna, eggs, and green beans",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1511357840105-748c95f0a7e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 30
      },
      {
        id: 410,
        name: "Kale Caesar",
        description: "Kale with Caesar dressing",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1505576399279-565b52d4ac71?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 20
      },
      {
        id: 411,
        name: "Pear and Gorgonzola",
        description: "Fresh pears with blue cheese",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1507048331197-7d4ac70811cf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 25
      },
      {
        id: 412,
        name: "Southwest Salad",
        description: "Black beans and corn salsa",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1543339308-43e59d6b73a6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 15
      },
      {
        id: 413,
        name: "Beet and Goat Cheese",
        description: "Roasted beets with goat cheese",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1505576633757-0ac1084af824?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 20
      },
      {
        id: 414,
        name: "Asian Chicken Salad",
        description: "Grilled chicken with Asian dressing",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 25
      },
      {
        id: 415,
        name: "Spinach and Strawberry",
        description: "Fresh spinach with strawberries",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 15
      },
      {
        id: 416,
        name: "Grilled Peach Salad",
        description: "Grilled peaches with arugula",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 15
      },
      {
        id: 417,
        name: "Roasted Vegetable Salad",
        description: "Seasonal roasted vegetables",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 10
      },
      {
        id: 418,
        name: "Citrus Avocado Salad",
        description: "Mixed citrus with avocado",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 20
      },
      {
        id: 419,
        name: "Pomegranate Salad",
        description: "Mixed greens with pomegranate",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 15
      },
      {
        id: 420,
        name: "Harvest Salad",
        description: "Fall vegetables with maple dressing",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
        cholesterolLevel: 20
      }
    ]
  };

  const handleAddToCart = (dish: any) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        id: dish.id,
        name: dish.name,
        price: dish.price,
        image: dish.image,
        cholesterolLevel: dish.cholesterolLevel
      }
    });
  };

  return (
    <div className="min-h-screen pt-20 pb-10 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-8">Our Menu</h1>
        
        {/* Category Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-2 rounded-full text-lg transition-colors ${
                activeCategory === category.id
                  ? 'bg-orange-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-orange-100'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Active Category Title */}
        <h2 className="text-3xl font-semibold text-center mb-8">
          {categories.find(cat => cat.id === activeCategory)?.name}
        </h2>
        
        {/* Dishes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {dishes[activeCategory as keyof typeof dishes].map((dish) => (
            <div key={dish.id} className="bg-white rounded-lg shadow-md overflow-hidden transform hover:scale-105 transition-transform">
              <div className="relative h-48">
                <img 
                  src={dish.image} 
                  alt={dish.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 bg-white px-2 py-1 rounded-full">
                  <span className="text-sm font-medium text-gray-600">{dish.cholesterolLevel} mg/dL</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-semibold">{dish.name}</h3>
                  <span className="text-lg font-bold text-orange-600">${dish.price}</span>
                </div>
                <p className="text-gray-600 mb-4">{dish.description}</p>
                <button 
                  onClick={() => handleAddToCart(dish)}
                  className="w-full bg-orange-600 text-white px-4 py-2 rounded-full hover:bg-orange-700 transition-colors flex items-center justify-center gap-2"
                >
                  <ShoppingCart size={20} />
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Menu;