import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Clock, Package, Truck, CheckCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface OrderStatus {
  id: string;
  status: 'preparing' | 'ready' | 'out_for_delivery' | 'delivered';
  customer_name: string;
  delivery_address: string;
  customer_phone: string;
  created_at: string;
  total_amount: number;
}

const statusSteps = [
  { key: 'preparing', label: 'Preparing', icon: Clock },
  { key: 'ready', label: 'Ready', icon: Package },
  { key: 'out_for_delivery', label: 'Out for Delivery', icon: Truck },
  { key: 'delivered', label: 'Delivered', icon: CheckCircle }
];

const TrackOrder = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [order, setOrder] = useState<OrderStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrder = async () => {
      if (!user || !id) return;

      try {
        const { data, error } = await supabase
          .from('orders')
          .select('*')
          .eq('id', id)
          .eq('user_id', user.id)
          .single();

        if (error) throw error;
        setOrder(data);
      } catch (error: any) {
        console.error('Error fetching order:', error);
        setError(
          error.message === 'Failed to fetch'
            ? 'Network error. Please check your connection and try again.'
            : 'Could not load order details. Please try again later.'
        );
        toast.error('Failed to load order details');
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();

    // Set up real-time subscription
    const subscription = supabase
      .channel('order_status_changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `id=eq.${id}`
        },
        (payload) => {
          setOrder(payload.new as OrderStatus);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [id, user]);

  if (loading) {
    return (
      <div className="min-h-screen pt-20 pb-10 bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen pt-20 pb-10 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-sm p-6 text-center">
            <h2 className="text-2xl font-semibold text-gray-800">Error</h2>
            <p className="text-gray-600 mt-2">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 bg-orange-600 text-white px-6 py-2 rounded-full hover:bg-orange-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen pt-20 pb-10 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-sm p-6 text-center">
            <h2 className="text-2xl font-semibold text-gray-800">Order Not Found</h2>
            <p className="text-gray-600 mt-2">This order doesn't exist or you don't have permission to view it.</p>
          </div>
        </div>
      </div>
    );
  }

  const currentStepIndex = statusSteps.findIndex(step => step.key === order.status);

  return (
    <div className="min-h-screen pt-20 pb-10 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h1 className="text-2xl font-bold mb-6">Order Tracking</h1>

          {/* Order Details */}
          <div className="mb-8">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Order ID</p>
                <p className="font-medium">{order.id}</p>
              </div>
              <div>
                <p className="text-gray-600">Order Date</p>
                <p className="font-medium">
                  {new Date(order.created_at).toLocaleDateString()}
                </p>
              </div>
              <div>
                <p className="text-gray-600">Delivery To</p>
                <p className="font-medium">{order.customer_name}</p>
                <p className="text-gray-600">{order.delivery_address}</p>
              </div>
              <div>
                <p className="text-gray-600">Contact</p>
                <p className="font-medium">{order.customer_phone}</p>
              </div>
            </div>
          </div>

          {/* Status Timeline */}
          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-px bg-gray-200" />
            <div className="space-y-8">
              {statusSteps.map((step, index) => {
                const Icon = step.icon;
                const isCompleted = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;

                return (
                  <div key={step.key} className="relative flex items-center">
                    <div className="flex-1 text-right pr-4">
                      {index % 2 === 0 && (
                        <div className={`${isCompleted ? 'text-orange-600' : 'text-gray-500'}`}>
                          {step.label}
                        </div>
                      )}
                    </div>
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center z-10 
                        ${isCompleted ? 'bg-orange-600' : 'bg-gray-200'} 
                        ${isCurrent ? 'ring-4 ring-orange-100' : ''}`}
                    >
                      <Icon className={`w-4 h-4 ${isCompleted ? 'text-white' : 'text-gray-500'}`} />
                    </div>
                    <div className="flex-1 pl-4">
                      {index % 2 === 1 && (
                        <div className={`${isCompleted ? 'text-orange-600' : 'text-gray-500'}`}>
                          {step.label}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Order Total */}
          <div className="mt-8 pt-6 border-t">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Amount</span>
              <span className="text-xl font-bold text-orange-600">
                ${order.total_amount.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackOrder;