import React, { useState, useEffect, useCallback } from 'react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { supabase, retryOperation, handleSupabaseError } from '../lib/supabase';

const CholesterolSettings = () => {
  const { state, dispatch } = useCart();
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [level, setLevel] = useState(state.maxCholesterolLevel);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchUserPreferences = useCallback(async () => {
    if (!user) return;

    setIsLoading(true);
    setError(null);

    try {
      const { data: existingPrefs, error: fetchError } = await retryOperation(() =>
        supabase
          .from('user_preferences')
          .select('max_cholesterol_level')
          .eq('user_id', user.id)
          .maybeSingle()
      );

      if (fetchError) throw fetchError;

      if (existingPrefs) {
        setLevel(existingPrefs.max_cholesterol_level);
        dispatch({ type: 'SET_MAX_CHOLESTEROL', payload: existingPrefs.max_cholesterol_level });
      } else {
        const defaultLevel = 200;
        const { error: upsertError } = await retryOperation(() =>
          supabase
            .from('user_preferences')
            .upsert({
              user_id: user.id,
              max_cholesterol_level: defaultLevel,
              updated_at: new Date().toISOString()
            })
        );

        if (upsertError) throw upsertError;

        setLevel(defaultLevel);
        dispatch({ type: 'SET_MAX_CHOLESTEROL', payload: defaultLevel });
      }
    } catch (error: any) {
      const errorMessage = handleSupabaseError(error);
      console.error('Error managing user preferences:', errorMessage);
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [user, dispatch]);

  useEffect(() => {
    fetchUserPreferences();
  }, [fetchUserPreferences]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error('Please sign in to save your preferences');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { error } = await retryOperation(() =>
        supabase
          .from('user_preferences')
          .upsert({
            user_id: user.id,
            max_cholesterol_level: level,
            updated_at: new Date().toISOString()
          })
      );

      if (error) throw error;

      dispatch({ type: 'SET_MAX_CHOLESTEROL', payload: level });
      setIsOpen(false);
      toast.success('Cholesterol limit updated successfully');
    } catch (error: any) {
      const errorMessage = handleSupabaseError(error);
      console.error('Error updating preferences:', errorMessage);
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const handleOpenSettings = () => setIsOpen(true);
    document.addEventListener('open-cholesterol-settings', handleOpenSettings);
    return () => document.removeEventListener('open-cholesterol-settings', handleOpenSettings);
  }, []);

  const cholesterolPercentage = (state.totalCholesterol / state.maxCholesterolLevel) * 100;
  const isHighCholesterol = cholesterolPercentage >= 80;

  return (
    <div className="fixed bottom-4 right-4 space-y-4">
      <div className="bg-white p-4 rounded-lg shadow-lg">
        <div className="mb-2 flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">Cholesterol Level</span>
          <span className="text-sm text-gray-600">{state.totalCholesterol}/{state.maxCholesterolLevel} mg/dL</span>
        </div>
        <div className="relative h-4 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`absolute left-0 top-0 h-full transition-all duration-300 ${
              isHighCholesterol ? 'bg-red-500' : 'bg-orange-500'
            }`}
            style={{ width: `${Math.min(cholesterolPercentage, 100)}%` }}
          />
        </div>
        {isHighCholesterol && (
          <div className="mt-2 flex items-center text-red-500 text-sm">
            <AlertTriangle className="w-4 h-4 mr-1" />
            <span>High cholesterol warning</span>
          </div>
        )}
      </div>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-96">
            {user ? (
              <>
                <h2 className="text-xl font-semibold mb-4">Set Cholesterol Limit</h2>
                <form onSubmit={handleSubmit}>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Maximum Cholesterol Level (mg/dL)
                    </label>
                    <input
                      type="number"
                      value={level}
                      onChange={(e) => setLevel(Number(e.target.value))}
                      className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                      max={300}
                      min={0}
                      disabled={isLoading}
                    />
                    <p className="text-sm text-gray-500 mt-1">Maximum allowed: 300 mg/dL</p>
                  </div>
                  {error && (
                    <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600">{error}</p>
                    </div>
                  )}
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsOpen(false)}
                      className="px-4 py-2 text-gray-600 hover:text-gray-800"
                      disabled={isLoading}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className={`px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 flex items-center gap-2 ${
                        isLoading ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save'
                      )}
                    </button>
                  </div>
                </form>
              </>
            ) : (
              <div className="text-center">
                <h2 className="text-xl font-semibold mb-4">Sign In Required</h2>
                <p className="text-gray-600 mb-6">
                  Please <Link to="/auth" className="text-orange-600 hover:text-orange-700">sign in</Link> or{' '}
                  <Link to="/auth" className="text-orange-600 hover:text-orange-700">create an account</Link> to set your cholesterol limit.
                </p>
                <button
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CholesterolSettings;