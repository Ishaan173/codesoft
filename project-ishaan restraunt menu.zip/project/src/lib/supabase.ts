import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || supabaseUrl === 'your-project-url') {
  throw new Error(
    'Please click the "Connect to Supabase" button in the top right corner to set up your database connection.'
  );
}

if (!supabaseAnonKey || supabaseAnonKey === 'your-anon-key') {
  throw new Error(
    'Missing or invalid Supabase anonymous key. Please check your environment variables.'
  );
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  },
  global: {
    headers: {
      'x-application-name': 'spice-fusion'
    }
  },
  db: {
    schema: 'public'
  }
});

// Utility function to retry failed requests
export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries = 3,
  delay = 1000,
  backoff = 2
): Promise<T> {
  let lastError: any;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * Math.pow(backoff, i)));
      }
    }
  }
  
  throw lastError;
}

// Utility function to handle Supabase errors
export function handleSupabaseError(error: any): string {
  if (error.message?.includes('Failed to fetch')) {
    return 'Network error: Unable to connect to the database. Please check your connection.';
  }
  if (error.code === 'PGRST116') {
    return 'Invalid data format. Please check your input.';
  }
  if (error.code === '23505') {
    return 'This record already exists.';
  }
  return error.message || 'An unexpected error occurred';
}