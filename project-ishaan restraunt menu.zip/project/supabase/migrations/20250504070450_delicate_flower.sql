/*
  # Enhanced Cholesterol Tracking

  1. New Tables
    - `dish_cholesterol`
      - `id` (uuid, primary key)
      - `dish_id` (uuid, foreign key to menu_items)
      - `cholesterol_level` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `user_cholesterol_preferences`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `max_daily_cholesterol` (integer)
      - `warning_threshold` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create dish_cholesterol table
CREATE TABLE IF NOT EXISTS dish_cholesterol (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dish_id uuid REFERENCES menu_items NOT NULL,
  cholesterol_level integer NOT NULL CHECK (cholesterol_level >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(dish_id)
);

-- Create user_cholesterol_preferences table
CREATE TABLE IF NOT EXISTS user_cholesterol_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  max_daily_cholesterol integer NOT NULL DEFAULT 300 CHECK (max_daily_cholesterol >= 0),
  warning_threshold integer NOT NULL DEFAULT 240 CHECK (warning_threshold >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable Row Level Security
ALTER TABLE dish_cholesterol ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_cholesterol_preferences ENABLE ROW LEVEL SECURITY;

-- Create policies for dish_cholesterol
CREATE POLICY "Dish cholesterol levels are viewable by everyone"
  ON dish_cholesterol
  FOR SELECT
  TO public
  USING (true);

-- Create policies for user_cholesterol_preferences
CREATE POLICY "Users can view their own cholesterol preferences"
  ON user_cholesterol_preferences
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own cholesterol preferences"
  ON user_cholesterol_preferences
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert their own cholesterol preferences"
  ON user_cholesterol_preferences
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at columns
CREATE TRIGGER update_dish_cholesterol_updated_at
  BEFORE UPDATE ON dish_cholesterol
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_cholesterol_preferences_updated_at
  BEFORE UPDATE ON user_cholesterol_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();