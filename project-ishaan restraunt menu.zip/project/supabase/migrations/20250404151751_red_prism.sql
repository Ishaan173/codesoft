/*
  # Add delivery tracking columns

  1. Changes
    - Add delivery tracking columns to orders table:
      - delivery_address (text): Customer's delivery address
      - customer_name (text): Customer's full name
      - customer_phone (text): Customer's contact number
      - status (text): Order status with default 'pending'

  2. Security
    - No changes to RLS policies (using existing policies)
*/

-- Add new columns to orders table
ALTER TABLE orders
ADD COLUMN IF NOT EXISTS delivery_address text,
ADD COLUMN IF NOT EXISTS customer_name text,
ADD COLUMN IF NOT EXISTS customer_phone text,
ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending';

-- Add check constraint for status values
DO $$ BEGIN
  ALTER TABLE orders
    ADD CONSTRAINT orders_status_check
    CHECK (status IN ('pending', 'preparing', 'ready', 'out_for_delivery', 'delivered'));
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;